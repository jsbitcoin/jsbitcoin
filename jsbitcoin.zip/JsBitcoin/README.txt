To use JsBitcoin to generate a wallet in cold storage without any internet connection on a secure computer just open the JsBitcoin.html file in your browser.
